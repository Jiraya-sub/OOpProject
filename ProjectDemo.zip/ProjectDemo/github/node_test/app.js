const http = require('http');

const server = http.createServer((req, res) => {
    res.write("Hello from Node.js App on AWS 🚀");
    res.end();
});

server.listen(5500, () => {
    console.log("Server running on port 5500");
});