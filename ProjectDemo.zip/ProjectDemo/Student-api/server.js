// ========================
//  IMPORTS
// ========================
const express = require("express");
const mongoose = require("mongoose");

const app = express();
app.use(express.json());


// ========================
//  DATABASE CONNECTION
// ========================
mongoose.connect("mongodb+srv://muzandemon106_db_user:0NNEF2qreZq3pEmz@cluster0.dek3cve.mongodb.net/Student_data")
    .then(() => console.log("Connected to MongoDB"))
    .catch((err) => console.log("DB Error:", err));


// ========================
//  STUDENT MODEL
// ========================
const Student = mongoose.model("Student_data", {
    name: String,
    age: Number,
    email: String,
    course: String
});


// ========================
//  ROUTES
// ========================

// Get all students
app.get("/students", async (req, res) => {
    const students = await Student.find();
    res.json(students);
});

// Get one student by name
app.get("/students/:name", async (req, res) => {
    const student = await Student.find({ name: req.params.name });
    res.json(student);
});

// Add a new student
app.post("/students", async (req, res) => {
    const student = new Student(req.body);
    await student.save();
    res.json(student);
});

// Update student by name
app.put("/students/:name", async (req, res) => {
    const updated = await Student.findOneAndUpdate(
        { name: req.params.name },
        req.body,
        { new: true }
    );
    res.json(updated);
});

// Delete student by name
app.delete("/students/:name", async (req, res) => {
    const result = await Student.deleteOne({ name: req.params.name });
    res.json(result);
});


// ========================
//  START SERVER
// ========================
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
