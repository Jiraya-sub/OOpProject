const express = require(express)
const mongoose = require(mongoose)

const app = express()
app.use(express.json())

mongoose.connect("")
    .then(() => console.log("DB Connected Succesfully"))
    .catch((err) => console.log("Error Encontered", err));

const Student = mongoose.model("Students_data", {
    name : String,
    age : Number,
    email : String,
    cource : String
});

app.get("/students", async(req, res) => {
    const students = await Student.find();
    res.json(students)
});

app.get("/students:/name", async(req, res) => {
    const students = await Student.find({name : req.params.name});
    res.json(students)
})

app.post("/students", async(req, res) => {
    const students = new Student(req.body);
    await students.save();
    res.json(students)

});

app.put("/students:/name", async(req, res) => {
    const updated = await Student.findOneAndUpdate(
        {name: req.params.name},
        req.body,
        {name : true}
    );
    res.json(students)
});

app.delete("students/:name", async(req, res) => {
    const result = await Student.deleteOne({name : req.params.name});
    res.json(result);
});

app.listen("3000", () => {
    console.log("")
})